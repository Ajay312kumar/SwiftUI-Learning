//
//  Constant.swift
//  Weatherly
//
//  Created by Ajay Kumar on 27/08/24.
//

import Foundation

enum Constant{
    
    static var weatherKey = "87654745f6f96fc6b3e187258dc908b1"
    
}
