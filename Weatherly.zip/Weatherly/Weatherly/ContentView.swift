//
//  ContentView.swift
//  Weatherly
//
//  Created by Ajay Kumar on 27/08/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Button("Get Coordinate"){
                Task{
                    let gepCoordinate = GeocodingClient()
                    let location = try! await gepCoordinate.coordinateByCity("huston")
                    print(location)
                }
            }
            
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
