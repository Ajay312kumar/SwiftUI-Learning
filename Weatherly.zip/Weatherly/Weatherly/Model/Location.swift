//
//  Location.swift
//  Weatherly
//
//  Created by Ajay Kumar on 27/08/24.
//

import Foundation


struct Location: Decodable{
    
    var name: String
    var lat: Double
    var long: Double
    var country: String
    var state: String
}




